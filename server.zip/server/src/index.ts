// diagnostics bootstrap: install crash/exception logging before any other import
import './diagnostics';
// Load environment variables FIRST before any other imports
import './env';

import express, {
  type Request,
  type Response,
  type NextFunction,
  type Express,
} from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import type { ReadableStream as WebReadableStream } from 'node:stream/web';
import { chatRouter } from './routes/chat';
import { storeMessageMeta } from './lib/message-meta-store';
import { historyRouter } from './routes/history';
import { sessionRouter } from './routes/session';
import { messagesRouter } from './routes/messages';
import { configRouter } from './routes/config';
import { feedbackRouter } from './routes/feedback';
import { ChatSDKError } from '@databricks/chatbot-core/errors';
import {
  SECURITY_HEADERS,
  securityHeadersMiddleware,
} from './middleware/security-headers';
import {
  createCsrfMiddleware,
  matchesOrigin,
  parseOrigins,
} from './middleware/csrf';

// ESM-compatible __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app: Express = express();
const isDevelopment = process.env.NODE_ENV !== 'production';
// Either let PORT be set by env or use 3001 for development and 3000 for production
// The CHAT_APP_PORT can be used to override the port for the chat app.
const PORT =
  process.env.CHAT_APP_PORT ||
  process.env.PORT ||
  (isDevelopment ? 3001 : 3000);

app.disable('x-powered-by');
app.use(securityHeadersMiddleware);

// CORS: the UI is served from the same origin in production, so cross-origin
// access is off unless explicitly allowed via ALLOWED_ORIGINS (comma-separated
// https origins, matched like the CSRF check).
// Never reflect arbitrary origins: requests carry the user's credentials.
const corsOrigins = new Set(parseOrigins(process.env.ALLOWED_ORIGINS));
if (corsOrigins.size > 0 || isDevelopment) {
  app.use(
    cors({
      origin: (origin, callback) =>
        callback(
          null,
          origin !== undefined &&
            (matchesOrigin(origin, corsOrigins) ||
              (isDevelopment && origin === 'http://localhost:3000')),
        ),
      credentials: true,
    }),
  );
}

app.use(createCsrfMiddleware({ isDevelopment }));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health check endpoint (for Playwright tests)
app.get('/ping', (_req, res) => {
  res.status(200).send('pong');
});

// API routes
app.use('/api/chat', chatRouter);
app.use('/api/history', historyRouter);
app.use('/api/session', sessionRouter);
app.use('/api/messages', messagesRouter);
app.use('/api/config', configRouter);
app.use('/api/feedback', feedbackRouter);

// Agent backend proxy (optional)
// If API_PROXY is set, proxy /invocations requests to the agent backend
const agentBackendUrl = process.env.API_PROXY;
if (agentBackendUrl) {
  console.log(`✅ Proxying /invocations to ${agentBackendUrl}`);
  const skippedUpstreamHeaders = new Set(
    Object.keys(SECURITY_HEADERS).map((name) => name.toLowerCase()),
  );
  app.post('/invocations', async (req: Request, res: Response) => {
    try {
      // The body is re-serialized, so drop the client's framing headers. Not
      // with `delete`: `npm run lint` rewrites that to `= undefined`, which
      // fetch rejects.
      const {
        'content-length': _contentLength,
        'transfer-encoding': _transferEncoding,
        ...forwardHeaders
      } = req.headers as Record<string, string>;

      const response = await fetch(agentBackendUrl, {
        method: req.method,
        headers: forwardHeaders,
        body:
          req.method !== 'GET' && req.method !== 'HEAD'
            ? JSON.stringify(req.body)
            : undefined,
      });

      // Copy status and headers, keeping this server's security and CORS headers
      res.status(response.status);
      response.headers.forEach((value, key) => {
        if (
          !skippedUpstreamHeaders.has(key) &&
          !key.startsWith('access-control-')
        ) {
          res.setHeader(key, value);
        }
      });

      // Stream the response body
      if (response.body) {
        await pipeline(
          Readable.fromWeb(response.body as WebReadableStream),
          res,
        );
      } else {
        res.end();
      }
    } catch (error) {
      if (res.headersSent) {
        // The stream was interrupted after the response started (e.g. the
        // client disconnected, which makes `pipeline` reject with
        // ERR_STREAM_PREMATURE_CLOSE). A 502 can no longer be sent.
        if (
          (error as NodeJS.ErrnoException)?.code !==
          'ERR_STREAM_PREMATURE_CLOSE'
        ) {
          console.error('[/invocations proxy] Stream error:', error);
        }
        res.destroy();
        return;
      }
      console.error('[/invocations proxy] Error:', error);
      res.status(502).json({
        error: 'Proxy error',
        message: error instanceof Error ? error.message : String(error),
      });
    }
  });
}

// Serve static files in production
if (!isDevelopment) {
  const clientBuildPath = path.join(__dirname, '../../client/dist');
  app.use(express.static(clientBuildPath));

  // SPA fallback - serve index.html for all non-API routes
  app.get(/^\/(?!api).*/, (_req, res) => {
    res.sendFile(path.join(clientBuildPath, 'index.html'));
  });
}

// Error handling middleware
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Error:', err);

  if (err instanceof ChatSDKError) {
    const response = err.toResponse();
    return res.status(response.status).json(response.json);
  }

  res.status(500).json({
    error: 'Internal Server Error',
    message: isDevelopment ? err.message : 'An unexpected error occurred',
  });
});

// Start MSW mock server in test mode
async function startServer() {
  if (process.env.PLAYWRIGHT === 'True') {
    console.log('[Test Mode] Starting MSW mock server for API mocking...');
    try {
      // Dynamically import MSW setup from tests directory (using relative path from server root)
      const modulePath = path.join(
        dirname(dirname(__dirname)),
        'tests',
        'api-mocking',
        'api-mock-server.ts',
      );
      console.log('[Test Mode] Attempting to load MSW from:', modulePath);

      const { mockServer } = await import(modulePath);

      mockServer.listen({
        onUnhandledRequest: (request: Request) => {
          console.warn(
            `[MSW] Unhandled ${request.method} request to ${request.url}`,
          );
        },
      });

      console.log('[Test Mode] MSW mock server started successfully');
      console.log(
        '[Test Mode] Registered handlers:',
        mockServer.listHandlers().length,
      );

      // Import captured request utilities for testing context injection
      const handlersPath = path.join(
        dirname(dirname(__dirname)),
        'tests',
        'api-mocking',
        'api-mock-handlers.ts',
      );
      const {
        getCapturedRequests,
        resetCapturedRequests,
        getLastCapturedRequest,
        resetMlflowAssessmentStore,
        getLastServingRequestHeaders,
      } = await import(handlersPath);

      // Test-only endpoint to get captured requests (for context injection testing)
      app.get('/api/test/captured-requests', (_req, res) => {
        res.json(getCapturedRequests());
      });

      // Test-only endpoint to get the last captured request
      app.get('/api/test/last-captured-request', (_req, res) => {
        const lastRequest = getLastCapturedRequest();
        if (lastRequest) {
          res.json(lastRequest);
        } else {
          res.status(404).json({ error: 'No captured requests' });
        }
      });

      // Test-only endpoint to reset captured requests
      app.post('/api/test/reset-captured-requests', (_req, res) => {
        resetCapturedRequests();
        res.json({ success: true });
      });

      // Test-only endpoint to reset MLflow assessment store
      app.post('/api/test/reset-mlflow-store', (_req, res) => {
        resetMlflowAssessmentStore();
        res.json({ success: true });
      });

      // Test-only endpoint to read headers from the last serving endpoint request
      app.get('/api/test/serving-request-headers', (_req, res) => {
        res.json(getLastServingRequestHeaders());
      });

      console.log(
        '[Test Mode] Test endpoints for context injection registered',
      );
    } catch (error) {
      console.error('[Test Mode] Failed to start MSW:', error);
      console.error(
        '[Test Mode] Error details:',
        error instanceof Error ? error.stack : error,
      );
    }

    // Registered outside the MSW try/catch so it's available even if MSW setup fails.
    // Lets tests simulate a message from an endpoint that doesn't return traces.
    app.post('/api/test/store-message-meta', (req, res) => {
      const { messageId, chatId, traceId } = req.body as {
        messageId: string;
        chatId: string;
        traceId: string | null;
      };
      storeMessageMeta(messageId, chatId, traceId ?? null);
      res.json({ success: true });
    });
  }

  app.listen(PORT, () => {
    console.log(`Backend server is running on http://localhost:${PORT}`);
    console.log(`Environment: ${isDevelopment ? 'development' : 'production'}`);
  });
}

startServer();

export default app;
