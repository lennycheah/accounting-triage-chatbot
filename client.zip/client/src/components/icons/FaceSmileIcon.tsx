import { forwardRef } from "react";
import { cn } from "@/lib/utils";

export interface FaceSmileIconProps extends React.SVGProps<SVGSVGElement> {
  /** Icon size in pixels. Default: 16 (DuBois standard). */
  size?: number | string;
  className?: string;
  /** Accessible label. When set, icon gets role="img". */
  ariaLabel?: string;
}

export const FaceSmileIcon = forwardRef<SVGSVGElement, FaceSmileIconProps>(
  ({ size = 16, className, ariaLabel, ...props }, ref) => (
    <svg
      ref={ref}
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
      className={cn("shrink-0", className)}
      aria-hidden={!ariaLabel}
      aria-label={ariaLabel}
      role={ariaLabel ? "img" : undefined}
      {...props}
    >
      <g fill="currentColor" clipPath="url(#FaceSmileIcon_svg__a)">
              <path
                fillRule="evenodd"
                d="M8 2.084a5.917 5.917 0 1 0 0 11.833A5.917 5.917 0 0 0 8 2.084M.583 8a7.417 7.417 0 1 1 14.834 0A7.417 7.417 0 0 1 .583 8"
                clipRule="evenodd"
              />
              <path d="M4.883 8.734a.75.75 0 0 1 1.048.146l.002.003.021.026q.032.038.103.114c.096.1.24.235.426.37.375.274.89.524 1.517.524s1.142-.25 1.517-.523a3.2 3.2 0 0 0 .55-.511.75.75 0 0 1 1.2.9l.029-.042-.03.043-.001.002-.002.002-.005.007-.015.019-.048.059q-.06.073-.17.188c-.143.15-.354.348-.626.546-.54.393-1.359.81-2.399.81s-1.858-.417-2.4-.81a4.7 4.7 0 0 1-.795-.734l-.048-.059-.015-.02-.005-.006-.002-.002v-.002h-.002a.75.75 0 0 1 .15-1.05" />
              <path
                fillRule="evenodd"
                d="M5.25 6A.75.75 0 0 1 6 5.25h.007a.75.75 0 0 1 0 1.5H6A.75.75 0 0 1 5.25 6M9.25 6a.75.75 0 0 1 .75-.75h.007a.75.75 0 1 1 0 1.5H10A.75.75 0 0 1 9.25 6"
                clipRule="evenodd"
              />
            </g>
            <defs>
              <clipPath>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
    </svg>
  )
);
FaceSmileIcon.displayName = "FaceSmileIcon";
