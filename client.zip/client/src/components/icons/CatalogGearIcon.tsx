import { forwardRef } from "react";
import { cn } from "@/lib/utils";

export interface CatalogGearIconProps extends React.SVGProps<SVGSVGElement> {
  /** Icon size in pixels. Default: 16 (DuBois standard). */
  size?: number | string;
  className?: string;
  /** Accessible label. When set, icon gets role="img". */
  ariaLabel?: string;
}

export const CatalogGearIcon = forwardRef<SVGSVGElement, CatalogGearIconProps>(
  ({ size = 16, className, ariaLabel, ...props }, ref) => (
    <svg
      ref={ref}
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
      className={cn("shrink-0", className)}
      aria-hidden={!ariaLabel}
      aria-label={ariaLabel}
      role={ariaLabel ? "img" : undefined}
      {...props}
    >
      <g fill="currentColor" fillRule="evenodd" clipPath="url(#CatalogGearIcon_svg__a)" clipRule="evenodd">
              <path d="M14 7.5V.75a.75.75 0 0 0-.75-.75H4.5A2.5 2.5 0 0 0 2 2.5v10.75A2.75 2.75 0 0 0 4.75 16H8v-1.5H4.75c-.69 0-1.25-.56-1.25-1.25V4.792c.306.134.644.208 1 .208h8v2.5zm-9.5-4a1 1 0 0 1 0-2h8v2z" />
              <path d="M13.125 10.081q.364.114.673.325l.88-.703.936 1.173-.88.702q.136.344.166.729l1.098.25-.334 1.463-1.098-.25a2.6 2.6 0 0 1-.466.584l.49 1.014-1.352.651-.489-1.014a2.6 2.6 0 0 1-.748 0l-.488 1.014-1.351-.65.488-1.015a2.6 2.6 0 0 1-.466-.584l-1.098.25-.334-1.462 1.098-.25q.031-.385.166-.73l-.88-.702.935-1.172.88.702q.31-.211.674-.325V8.955h1.5zm.263 2.42a1.013 1.013 0 1 1-2.026 0 1.013 1.013 0 0 1 2.026 0" />
            </g>
            <defs>
              <clipPath>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
    </svg>
  )
);
CatalogGearIcon.displayName = "CatalogGearIcon";
